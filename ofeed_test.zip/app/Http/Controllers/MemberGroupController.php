<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MemberGroupController extends Controller
{
    //
}
