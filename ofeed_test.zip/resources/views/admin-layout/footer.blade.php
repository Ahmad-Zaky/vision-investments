<footer class="footer text-center">
  All Rights Reserved by Ample admin. Designed and Developed by
  <a href="https://wrappixel.com">WrapPixel</a>.
</footer>