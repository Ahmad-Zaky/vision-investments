@extends('front-layout.layout')
@section('content')

@endsection