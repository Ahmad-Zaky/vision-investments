// Exports the "mobile" theme for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/themes/mobile')
//   ES2015:
//     import 'tinymce/themes/mobile'
require('./theme.js');